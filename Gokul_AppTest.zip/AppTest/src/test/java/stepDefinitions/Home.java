package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class Home 
{
	
	
	String Trade_Balance;
	String expected_label;
	String trade_label;
	String Remaining_trade_balance_label;
	String Remaning_Trade_Balance_value;
	String Total_outstanding_label;
	String Total_Trade_Balance_Label;
	String Margin_Balance_label;
	AndroidDriver<AndroidElement> driver;
@Given("^Navigated to the Home page$")
public void verify_trade_balance() throws Throwable
{
	File appDir = new File("src");
    File app = new File(appDir, "app-debug.apk");
    DesiredCapabilities capabilities = new DesiredCapabilities();
    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    
    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
    
    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
	driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
	driver.pressKeyCode(66); 
	driver.getKeyboard();
	
	driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	
	
	trade_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_today_balance_label")).getText();
	expected_label="Today’s Remaining Trade Balance";
	if(trade_label.equalsIgnoreCase(expected_label))
	{
		System.out.println("Trade label values matches");
	}
	else
	{
		System.out.println("Not matches");
	}
	Trade_Balance=driver.findElement(By.xpath("//android.widget.TextView[@index='1']")).getText();
	System.out.println("Trade Balance"+ Trade_Balance );
	
}
@When("^The user clicks the dropdown button in the page$")
public void click_expand_tradebalancebutton()
{
	driver.findElement(By.id("com.mbb.mketrade:id/img_expand_trade_balance")).click();
}
@Then("^Remaining Trade Balance, Total Outstanding payment, Total Trade Balance, Margin Balance details will be displayed$")
public void getTradeBalance()
{
	// Trade balance
	Remaining_trade_balance_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Remaining Trade Balance']")).getText();
	String Trade_balance_expected="Remaining Trade Balance";
	if(Remaining_trade_balance_label.equalsIgnoreCase(Trade_balance_expected))
	{
		System.out.println("Remaning Trade balance text matches");
		
	}
	String Remaning_Trade_Balance=driver.findElement(By.id("com.mbb.mketrade:id/txt_remaining_trade_balance")).getText();
	System.out.println("Remaning_Trade_Balance"+ Remaning_Trade_Balance);
	
	// Outstanding Payments
	Total_outstanding_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Total Outstanding Payments']")).getText();
	String total_outstanding_expected="Total Outstanding Payments";
	if(Total_outstanding_label.equalsIgnoreCase(total_outstanding_expected))
	{
		System.out.println("Total outstanding label matches");
	}
	String Total_outstanding_paymnets=driver.findElement(By.id("com.mbb.mketrade:id/txt_total_outstanding_payments")).getText();
	System.out.println("Total_outstanding_paymnets"+ Total_outstanding_paymnets);
	
	//Total Trade Balance
	Total_Trade_Balance_Label=driver.findElement(By.xpath("//android.widget.TextView[@text='Total Trade Balance']")).getText();
	String Trade_Balance_label_expected="Total Trade Balance";
	if(Total_Trade_Balance_Label.equalsIgnoreCase(Trade_Balance_label_expected))
	{
		System.out.println("Total Total Trade Balance label matched");
	}
	String Total_Trade_balance=driver.findElement(By.id("com.mbb.mketrade:id/txt_total_trade_balance")).getText();
	System.out.println("Total_Trade_balance" + Total_Trade_balance );
	
	// Margin Balance
	Margin_Balance_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Margin Balance']")).getText();
	String Margin_Balance_expected="Margin Balance";
	if(Margin_Balance_label.equalsIgnoreCase(Margin_Balance_expected))
	{
		System.out.println("margin Label matched");
	}
	String Margin_Label_payments=driver.findElement(By.id("com.mbb.mketrade:id/txt_margin_balance")).getText();
	System.out.println("Margin_Label_payments"+ Margin_Label_payments);
	
	//verify button able to hide
	
	driver.findElement(By.xpath("//android.widget.ImageView[@index='1']")).click();
	//driver.findElement(By.className("android.widget.ImageView")).click();
	if(trade_label.equalsIgnoreCase(expected_label))
	{
		System.out.println("After clicking button hide");
	}
}

}
