package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;

public class Loginpage {
	 
	 AndroidDriver<AndroidElement> driver;
	
	@Given("^Open the application on mobile device$")
	public void Launchapplication() throws MalformedURLException
	{
		/*path=System.getProperty("user.dir");
		DesiredCapabilities cap= new DesiredCapabilities();
		cap.setCapability("BROWSER_NAME", "Android");
		cap.setCapability("VERSION","6.0");
		cap.setCapability("deviceName","Lenovo");
		cap.setCapability("platformName", "Android");
		cap.setCapability("", "");*/
		
		File appDir = new File("src");
	     File app = new File(appDir, "app-debug.apk");
	     DesiredCapabilities capabilities = new DesiredCapabilities();
	     capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	     capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	     driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
		
		
	}  
	@When("^click the Login button$")
	public void click_login()
	{
		driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	}
	/*@When("^Enter the username as \"([^\"]*)\" password on the Login page$")
	public void entercredentials() throws InterruptedException
	{
		Thread.sleep(100);
		//driver.findElement(By.xpath("//android.widget.EditText[@text='Username']")).sendKeys("mt001");
		//driver.findElement(By.xpath("//android.widget.EditText[@text='Password']")).sendKeys("abcd1234");
		driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
	}*/
	
	@When("^Enter the username as  password as on the Login page$")
	public void enter_the_username_as_password_as_on_the_Login_page() throws Throwable 
	{
	WebDriverWait wait=new WebDriverWait(driver,30);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/txt_sign_up")));
		String signup=driver.findElement(By.id("com.mbb.mketrade:id/txt_sign_up")).getText();
		String expected_signup="Sign up for a new account";
		if(signup.equalsIgnoreCase(expected_signup))
		{
			System.out.println("Sign up button displayed");
		}
		else
		{
			System.out.println("Sign up button not displayed");
		}
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
	}
	@When("^click the Login Button$")
	public void click_loginbutton()
	{
		//driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	}
	@Then("^User should Navigate to the Home screen$")
	public void verifying_navigating_homepage()
	{
		String gethome=driver.findElement(By.xpath("//android.widget.TextView[@text='Home']")).getText();
		if (gethome.equalsIgnoreCase("Home"))
		{
			System.out.println("Suuceesfully Login to the Application");
		}
		
	}
	
	
	

}
