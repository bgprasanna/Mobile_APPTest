package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ch.qos.logback.core.net.SyslogOutputStream;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class News 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^user navigated to the Discover page$")
	public void Navigate_to_discover() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	}
	
	@When("^The user Swipe to the news section$")
	public void swipeto_newssection()
	{
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
		
		String discover_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).getText();
		String expected_discover_label="Discover";
		if(discover_label.equalsIgnoreCase(expected_discover_label))
		{
			System.out.println("discover_label"+discover_label);
		}
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Discover']")));
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
	}
	@Then("^The news details will be displayed$")
	public void verify_news()
	{
		System.out.println("Verify news");
		boolean verify_news=driver.findElement(By.id("com.mbb.mketrade:id/news_title")).isDisplayed();
		if(verify_news)
		{
			String get_news=driver.findElement(By.id("com.mbb.mketrade:id/news_title")).getText();
			System.out.println("get_news"+ get_news);
			
			String date_view=driver.findElement(By.id("com.mbb.mketrade:id/date_view")).getText();
			System.out.println(date_view);
			
			String share_symbol=driver.findElement(By.id("com.mbb.mketrade:id/txt_share")).getText();
			System.out.println("share_symbol" + share_symbol);
			
			boolean imagecontent=driver.findElement(By.id("com.mbb.mketrade:id/news_img_content")).isDisplayed();
			if(imagecontent)
			{
				System.out.println("imagecontent Displayed");
			}
			else
			{
				System.out.println("Image content not displayed");
			}
			WebDriverWait wait=new WebDriverWait(driver,30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/txt_view_more")));
			String view_more=driver.findElement(By.id("com.mbb.mketrade:id/txt_view_more")).getText();
			String viewmore_expected="View More";
			if(view_more.equalsIgnoreCase(viewmore_expected))
			{
				System.out.println("View More Displayed");
			}
			else
			{
				System.out.println("View more not displayed");
			}
		}
		else
		{
			System.out.println("news not available");
		}
		
	}

}
