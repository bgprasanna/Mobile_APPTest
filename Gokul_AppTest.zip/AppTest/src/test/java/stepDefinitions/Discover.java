package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class Discover 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^User Navigated to the Discover page$")
	public void Navigate_to_discover() throws MalformedURLException
	{
		
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
		
		String discover_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).getText();
		String expected_discover_label="Discover";
		if(discover_label.equalsIgnoreCase(expected_discover_label))
		{
			System.out.println("discover_label"+discover_label);
		}
		
		String get_viewing_name=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name")).getText();
		System.out.println(get_viewing_name);
		
		String global_selector=driver.findElement(By.id("com.mbb.mketrade:id/txt_global_filter")).getText();
		System.out.println("global_selector"+ global_selector);
		
		String all_selector=driver.findElement(By.id("com.mbb.mketrade:id/txt_sector_filter")).getText();
		System.out.println("all_selector"+ all_selector);
		
	}
	
	@When("^User clicks the Refine button$")
	public void click_refine_button()
	{
		driver.findElement(By.id("com.mbb.mketrade:id/txt_refine")).click();
	}
	
	@Then("^Selectors for searching filter will be applied$")
	public void choosing_options()
	{
		// choosing the selector
		driver.findElement(By.id("com.mbb.mketrade:id/tb_oil_gas")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/tb_real_estate")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/tb_technology")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/tb_energy")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/tb_financials")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/tb_retail")).click();
		
		//clicking the apply button
		driver.findElement(By.id("com.mbb.mketrade:id/btn_settings")).click();
					
	}

}
