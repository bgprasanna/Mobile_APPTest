package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Duration;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class Welcome {
	AndroidDriver<AndroidElement> driver;
	
	@Given("^User login to the app$")
	public void login_to_app() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	}
	
	@When("^User navigated to the Home page$")
	public void navigate_to_homepage()
	{
		String Get_Home=driver.findElement(By.xpath("//android.widget.TextView[@text='Home']")).getText();
		String expected_Homepage="Home";
		if(Get_Home.equalsIgnoreCase(expected_Homepage))
		{
			System.out.println("Navigated to the home page");
		}
		else
		{
			System.out.println("Not navigated to the home page");
		}
	}
	
	@Then("^Good Morning message is displayed$")
	public void Welcome_message()
	{
		
		String welcome_message_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_greeting")).getText();
		if(welcome_message_label.contains("Good"))
		{
		System.out.println("welcome_message_label"+welcome_message_label);
		}
		else
		{
			System.out.println("Greetings message not displayed");
		}
		
		String person_name=driver.findElement(By.id("com.mbb.mketrade:id/txt_username")).getText();
		int length=person_name.length();
		if(length>0)
		{
			System.out.println("person_name is displayed"+ person_name );
		}
		else
		{
			System.out.println("Person name is not displayed");
		}
		
		String Alert_message_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_no_net_worth")).getText();
		String expected_label="You will be able to view your net worth after your first trade";
		if(Alert_message_label.equalsIgnoreCase(expected_label))
		{
			System.out.println("Net worth message matches");
		}
		else
		{
			System.out.println("Net worth message not matches");			
		}
		
	}
	@And("^Watchlist should be displayed$")
	public void watchlist()
	{
		String watchlist_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Your Watchlist']")).getText();
		String expected_watchlist="Your Watchlist";
		if(watchlist_label.equalsIgnoreCase(expected_watchlist))
		{
			System.out.println("Watchlist matches");
		}
		else
		{
			System.out.println("Watchlist not matches");
		}
		String stocks_message=driver.findElement(By.xpath("//android.widget.TextView[@text='Start adding stocks under your watch']")).getText();
		String expected_message="Start adding stocks under your watch";
		if(stocks_message.equalsIgnoreCase(expected_message))
		{
			System.out.println("Stocks message displayed");
		}
		else
		{
			System.out.println("Stocks message not displayed");
		}
		String add_stocks=driver.findElement(By.id("com.mbb.mketrade:id/txt_add_stocks_now")).getText();
		String expected_stocks="Add Stocks Now";
		if(add_stocks.equalsIgnoreCase(expected_stocks))
		{
			System.out.println("Add stocks message displayed");
		}
		else
		{
			System.out.println("Stocks message not displayed");
		}
		
		/*Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);
		TouchAction touch=new TouchAction(driver);
		
		touch.press(x,top_y).moveTo(x,bottom_y).release().perform();*/
		
		
		/*Dimension size=driver.manage().window().getSize();
		
		Double ScreenWidthStart = size.getWidth() * 0.8;
		int scrollStart = ScreenWidthStart.intValue();
		
		Double ScreenWidthEnd = size.getWidth() * 0.2;
		int scrollEnd = ScreenWidthEnd.intValue();*/
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
        		
	}
	
	@And("^Upcoming events also displayed$")
	public void upcomingevents()
	{
		String upcoming_events_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Upcoming Events']")).getText();
		String expected_upcoming_events_label="Upcoming Events";
		if(upcoming_events_label.equalsIgnoreCase(expected_upcoming_events_label))
		{
			System.out.println("Upcoming events label pass");
		}
		else
		{
			System.out.println("Upcoming events label not pass");
		}
		String Trade_details=driver.findElement(By.id("com.mbb.mketrade:id/market_name")).getText();
		int size_1=Trade_details.length();
		if(size_1>0)
		{
			System.out.println("Trade details displayed");
		}
		else
		{
			System.out.println("Trade details not displayed");
		}
		String Trade_location=driver.findElement(By.id("com.mbb.mketrade:id/address")).getText();
		int size_Trade=Trade_location.length();
		if(size_Trade>0)
		{
			System.out.println("Trade Address details displayed");
		}
		else
		{
			System.out.println("Trade Address details not displayed");
		}
		String verify_month=driver.findElement(By.id("com.mbb.mketrade:id/month_view")).getText();
		int size_month=verify_month.length();
		if(size_month>0)
		{
			System.out.println("Month available");
		}
		else
		{
			System.out.println("Month not available");
		}
		String date_verify=driver.findElement(By.id("com.mbb.mketrade:id/date_view")).getText();
		System.out.println("date_verify"+ date_verify);
	}
	@And("^stock help message is displayed$")
	public void Footerevents()
	{
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
        
        String help_message_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Let us help you find stocks that are suitable for you']")).getText();
        String expected_help_label="Let us help you find stocks that are suitable for you";
        if(help_message_label.equalsIgnoreCase(expected_help_label))
        {
        	System.out.println("Help message identified Pass");
        }
        else
        {
        	System.out.println("Help message not identified");
        }
        String goals_message=driver.findElement(By.id("com.mbb.mketrade:id/btn_based_on_my_goals")).getText();
        String Goals_label="BASED ON MY GOALS";
        if(goals_message.equalsIgnoreCase(Goals_label))
        {
        	System.out.println("Goals Message identifed pass");
        }
        else
        {
        	System.out.println("Goals message not identifed");
        }
        String stoclscreener_message=driver.findElement(By.id("com.mbb.mketrade:id/txt_stock_screener")).getText();
        String expected_stock_screener="Stock Screener";
        if(stoclscreener_message.equalsIgnoreCase(expected_stock_screener))
        {
        	System.out.println("Stock screener Pass");
        }
        else
        {
        	System.out.println("Screener screener fail");
        }
        
	}
	
}
