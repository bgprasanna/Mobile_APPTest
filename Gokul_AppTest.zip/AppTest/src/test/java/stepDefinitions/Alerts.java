package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.swing.plaf.synth.SynthScrollBarUI;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class Alerts {
	
	AndroidDriver<AndroidElement> driver;
	@Given("^Navigated to the App with valid credentials$")
	public void navigateapp_valid_credentials() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	}
	@When("^The user click the Alerts menu in the top$")
	public void click_Alerts()
	{
		boolean Alert=driver.findElement(By.xpath("//android.widget.TextView[@text='Alerts']")).isDisplayed();
		if(Alert)
		{
			driver.findElement(By.xpath("//android.widget.TextView[@text='Alerts']")).click();
			System.out.println("Alert menu found");
		}
		else
		{
			System.out.println("Alert menu not found");
		}
	}
	@Then("^Contents available in the Alert menu should be displayed$")
	public void list_Alertrecords()
	{
		System.out.println("Alert details will be displayed no records found");
	}

}
