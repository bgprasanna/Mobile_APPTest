package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ch.qos.logback.core.net.SyslogOutputStream;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class View_upcoming_events 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^User Navigated to the Upcoming events in the Home page$")
	public void navigate_Home_upcomingevents() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
	}
	@When("^User clicks the corresponding upcoming event details$")
	public void click_corresponding_upcomingEvents() throws InterruptedException
	{
		System.out.println("navigated");
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/txt_add_stocks_now")));
        
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
		
	}
	@Then("^Full details of the corresponding event is displayed$")
	public void view_full_upcomingdetails()
	{
		System.out.println("View Detail");
		String get_event_name=driver.findElement(By.id("com.mbb.mketrade:id/date_view")).getText();
		driver.findElement(By.id("com.mbb.mketrade:id/date_view")).click();
		
		String event_title=driver.findElement(By.id("com.mbb.mketrade:id/txt_news_title")).getText();
		System.out.println("event_title"+ event_title);
		
		String get_month=driver.findElement(By.id("com.mbb.mketrade:id/month_view")).getText();
		System.out.println("get_month" +get_month );
		
		String get_date=driver.findElement(By.id("com.mbb.mketrade:id/date_view")).getText();
		System.out.println("get_date"+ get_date);
		
		String get_address=driver.findElement(By.id("com.mbb.mketrade:id/address")).getText();
		System.out.println("get_address" + get_address);
		
		String get_time_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_time_label")).getText();
		System.out.println("get_time"+get_time_label);
		
		String gettime_details=driver.findElement(By.id("com.mbb.mketrade:id/txt_time")).getText();
		System.out.println(gettime_details);
		
		String venue_details_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_venue_label")).getText();
		System.out.println(venue_details_label);
		
		String venue_details=driver.findElement(By.id("com.mbb.mketrade:id/txt_venue_building")).getText();
		System.out.println(venue_details);

		String venue_address=driver.findElement(By.id("com.mbb.mketrade:id/txt_venue_address")).getText();
		System.out.println(venue_address);
		
		String speakers=driver.findElement(By.id("com.mbb.mketrade:id/txt_speakers_label")).getText();
		System.out.println(speakers);
		
		String speaker_name=driver.findElement(By.id("com.mbb.mketrade:id/txt_speakers_name")).getText();
		System.out.println(speaker_name);

		String speaker_company=driver.findElement(By.id("com.mbb.mketrade:id/txt_speakers_company")).getText();
		System.out.println(speaker_company);
		
		String news_content=driver.findElement(By.id("com.mbb.mketrade:id/txt_new_content")).getText();
		System.out.println(news_content);
		
		driver.findElement(By.id("com.mbb.mketrade:id/close_upcoming_events")).click();
		
		
		
	}

}
