package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class MKEInsightsSwipe
{
	
	 public AndroidDriver<AndroidElement> driver;
	@Given("^Navigated to the Discover page$")
	public void navigate_Discover() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
	}
	
	@When("^User swipe the page from right to left$")
	public void swipe_the_slider() throws InterruptedException
	{
		
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='MKE Insights']")));
		
		Dimension size = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx = (int) (size.width * 0.90);
		  int endx = (int) (size.width * 0.05);
		  int starty = size.height / 2;
		  
		  TouchAction ta=new TouchAction(driver)
		  .press(PointOption.point(startx,starty)).moveTo(PointOption.point(endx,starty)).release().perform();
	}
	@Then("^Next page of the image slider should be displayed$")
	public void swipe_righttoleft()
	{
		
		String text_title=driver.findElement(By.id("com.mbb.mketrade:id/title")).getText();
		String expected_title="China Banks:Cutting RRR to boost loan groth";
		Assert.assertEquals(text_title, expected_title);
		
		String text_description=driver.findElement(By.id("com.mbb.mketrade:id/txt_description")).getText();
		int size=text_description.length();
		if(size>0)
		{
			System.out.println("Description displayed");
		}
		else
		{
			System.out.println("Description not displayed");
		}
		String insights_time=driver.findElement(By.id("com.mbb.mketrade:id/mke_insights_time")).getText();
		System.out.println(insights_time);
		
		boolean sharecontent=driver.findElement(By.id("com.mbb.mketrade:id/layout_share_content")).isDisplayed();
		if(sharecontent)
		{
			System.out.println("Share content is displayed");
		}
		else
		{
			System.out.println("Share content not displayed");
		}
			Dimension size_1 = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx = (int) (size_1.width * 0.90);
		  int endx = (int) (size_1.width * 0.05);
		  int starty = size_1.height / 2;
		  
		  TouchAction ta=new TouchAction(driver)
		  .press(PointOption.point(startx,starty)).moveTo(PointOption.point(endx,starty)).release().perform();
		  
		  Dimension size_2 = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx_2 = (int) (size_2.width * 0.90);
		  int endx_2 = (int) (size_2.width * 0.05);
		  int starty_2 = size_2.height / 2;
		  
		  TouchAction ta_2=new TouchAction(driver)
		  .press(PointOption.point(startx_2,starty_2)).moveTo(PointOption.point(endx_2,starty_2)).release().perform();
		  
		  Dimension size_3 = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx_3 = (int) (size_3.width * 0.90);
		  int endx_3 = (int) (size_3.width * 0.05);
		  int starty_3 = size_3.height / 3;
		  
		  TouchAction ta_3=new TouchAction(driver)
		  .press(PointOption.point(startx_3,starty_3)).moveTo(PointOption.point(endx_3,starty_3)).release().perform();
		  
		  Dimension size_4 = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx_4 = (int) (size_4.width * 0.90);
		  int endx_4 = (int) (size_4.width * 0.05);
		  int starty_4 = size_4.height / 3;
		  
		  TouchAction ta_4=new TouchAction(driver)
		  .press(PointOption.point(startx_4,starty_4)).moveTo(PointOption.point(endx_4,starty_4)).release().perform();
		  
		  
	}

}
