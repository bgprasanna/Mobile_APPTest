package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class Discover_MKEInsights 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^User Login to the Application$")
	public void login_application() throws MalformedURLException
	{
		
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		
	}
	
	@When("^User clicks the Discover menu$")
	public void click_refine_button()
	{
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
	}
	
	@Then("^MKE Insights details are displayed$")
	public void view_insights_details()
	{
		String MKEInsights_label=driver.findElement(By.xpath("//android.widget.TextView[@text='MKE Insights']")).getText();
		String expected_MKE_label="MKE Insights";
		if(MKEInsights_label.equalsIgnoreCase(expected_MKE_label))
		{
			System.out.println("MKE insights values matches");			
		}
		else
		{
			System.out.println("MKE insights values not matches");
		}
		String MKE_title=driver.findElement(By.id("com.mbb.mketrade:id/title")).getText();
		System.out.println("MKE_title"+ MKE_title);
		
		//Buy or Sell
		String buyorsell=driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).getText();
		if(buyorsell.equalsIgnoreCase("buy"))
		{
			System.out.println("Buy value"+ buyorsell);
		}
		else if(buyorsell.equalsIgnoreCase("sell"))
		{
			System.out.println("Sell value"+ buyorsell);
		}
		else
		{
			System.out.println("Invalid value");
		}
		// Stock Price
		String stock_price=driver.findElement(By.id("com.mbb.mketrade:id/stock_price")).getText();
		System.out.println("stock_price"+ stock_price);
		
		// Insights time
		String insights_time=driver.findElement(By.id("com.mbb.mketrade:id/mke_insights_time")).getText();
		System.out.println(insights_time);
		//share symbol
		boolean sharesymbol=driver.findElement(By.id("com.mbb.mketrade:id/icon_share")).isDisplayed();
		if(sharesymbol)
		{
			System.out.println("Share icon is displayed");
		}
		//share button
		String share_button=driver.findElement(By.id("com.mbb.mketrade:id/txt_share")).getText();
		String expected_sharevalue="Share";
		Assert.assertEquals(share_button, expected_sharevalue);
		
	}
	
	@Given("^User navigated to the MKE Insights section in the Discover page$")
	public void navigate_MKEinsightspage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/buyOrSell")));
		boolean buysell =driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).isDisplayed();
		if(buysell)
		{
			System.out.println("Available Insights page");
		}
		else
		{
			System.out.println("Not Available in Insights page");
		}
	}
	
	@When("^The user clicks Sell buy link$")
	public void click_sellbuy_content()
	{
		driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).click();
	}
	
	@Then("^The page navigates to the corresponding page having more details$")
	public void MKE_complete_detailedview()
	{
		String MKE_get_label=driver.findElement(By.id("com.mbb.mketrade:id/section_title")).getText();
		System.out.println("MKE_get_label"+ MKE_get_label);
		
		boolean sharesymbol=driver.findElement(By.xpath("//android.widget.ImageView[@index='0']")).isDisplayed();
		if(sharesymbol)
		{
			System.out.println("Share symbol is displayed");
		}
		else
		{
			System.out.println("Share symbol is not displayed");
		}
		
		String share_gettext=driver.findElement(By.xpath("//android.widget.TextView[@text='Share']")).getText();
		String expected_share_label="Share";
		Assert.assertEquals(share_gettext, expected_share_label);
		
		// Market name
		String market_name=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name")).getText();
		System.out.println("market_name"+ market_name);
		
		//Date View
		String date_view=driver.findElement(By.id("com.mbb.mketrade:id/date_view")).getText();
		System.out.println("date_view"+ date_view);
		
		String txtbuysell=driver.findElement(By.id("com.mbb.mketrade:id/txt_buy_sell")).getText();
		if(txtbuysell.equalsIgnoreCase("BUY"))
		{
			System.out.println("BUY value"+ txtbuysell );	
		}
		else if(txtbuysell.equalsIgnoreCase("SELL"))
		{
			System.out.println("SELL value"+ txtbuysell  );
		}
		else
		{
			System.out.println("Invalid value");
		}
		//Stock name
		String txt_stockname=driver.findElement(By.id("com.mbb.mketrade:id/txt_stock_name")).getText();
		System.out.println("txt_stockname");
		
		boolean plusbutton=driver.findElement(By.xpath("//android.widget.ImageView[@index='2']")).isDisplayed();
		if(plusbutton)
		{
			System.out.println("Plus button is displayed");
		}
		else
		{
			System.out.println("Plus button not displayed");
		}
		
		String Targetpricelabel=driver.findElement(By.id("com.mbb.mketrade:id/txt_target_price_label")).getText();
		System.out.println(Targetpricelabel);
		
		String Targetprice=driver.findElement(By.id("com.mbb.mketrade:id/txt_target_price")).getText();
		System.out.println(Targetprice);
		
		String Totalnetworthlabel=driver.findElement(By.id("com.mbb.mketrade:id/txt_net_worth_label")).getText();
		System.out.println(Totalnetworthlabel);
		
		String Total_networth=driver.findElement(By.id("com.mbb.mketrade:id/txt_net_worth")).getText();
		System.out.println(Total_networth);
		
		boolean gainorloss=driver.findElement(By.id("com.mbb.mketrade:id/gain_or_loss")).isDisplayed();
		if(gainorloss)
		{
			System.out.println("Gain or Loss symbol displayed");
		}
		else
		{
			System.out.println("Gain or Loss symbol not displayed");
		}
		
		String last_percentage=driver.findElement(By.id("com.mbb.mketrade:id/last_price_percentage")).getText();
		System.out.println(last_percentage);
		
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/btn_download")));
		
		boolean download_button=driver.findElement(By.id("com.mbb.mketrade:id/btn_download")).isDisplayed();
		if(download_button)
		{
			driver.findElement(By.id("com.mbb.mketrade:id/btn_download")).click();
		}
		else
		{
			System.out.println("Download button is not displayed");
		}
		WebDriverWait wait_close=new WebDriverWait(driver,30);
		wait_close.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/img_close")));
		boolean closebutton=driver.findElement(By.id("com.mbb.mketrade:id/img_close")).isDisplayed();
		if(closebutton)
		{
			System.out.println("Close button is available");
		}
		else
		{
			System.out.println("Close button not available");
		}
	}
	
	@When("^scroll down to the same page$")
	public void scrolldown_Relatedtopics()
	{		        
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
	}
	@Then("^Related Topics is available$")
	public void Related_topics()
	{
		boolean Related_topics=driver.findElement(By.xpath("//android.widget.TextView[@text='Related Topics']")).isDisplayed();
		if(Related_topics)
		{
			System.out.println("Related topics are available");
			String gettopics_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Stocks']")).getText();
			String expected_topics="Stocks";
			Assert.assertEquals(gettopics_label, expected_topics);
			String gettopocs_label1=driver.findElement(By.xpath("//android.widget.TextView[@text='Real Estate']")).getText();
			String expected_realestate="Real Estate";
			Assert.assertEquals(gettopocs_label1, expected_realestate);
			String Rettail_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Retail']")).getText();
			String expected_retail="Retail";
			Assert.assertEquals(Rettail_label, expected_retail);
		}
		else
		{
			System.out.println("No Related topics are available");
		}
	}
	@And("^Related Stocks Details are available$")
	public void Related_Stocks_details()
	{
		boolean Related_stocks_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_retated_stocks_label")).isDisplayed();
		if(Related_stocks_label)
		{
			String totalstockscount=driver.findElement(By.id("com.mbb.mketrade:id/txt_retated_stocks_count")).getText();
			System.out.println(totalstockscount);
			
			String stock_name=driver.findElement(By.id("com.mbb.mketrade:id/txt_related_stock_name")).getText();
			System.out.println("stock_name" +stock_name );
			
			String stock_code=driver.findElement(By.id("com.mbb.mketrade:id/txt_related_stock_code")).getText();
			System.out.println("stock_code"+ stock_code);
			
			String stock_price=driver.findElement(By.id("com.mbb.mketrade:id/txt_related_stock_price")).getText();
			System.out.println("stock_price"+ stock_price);
			
			boolean gainorloss=driver.findElement(By.id("com.mbb.mketrade:id/img_related_stock_gain_or_loss")).isDisplayed();
			if(gainorloss)
			{
				System.out.println("Gain or Loss Displayed");
			}
			else
			{
				System.out.println("Gain or Loss not displayed");
			}
			String percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_related_stock__price_percentage")).getText();
			System.out.println("percentage"+ percentage);
			
			boolean stock_expand=driver.findElement(By.id("com.mbb.mketrade:id/img_related_stock_expand")).isDisplayed();
			if(stock_expand)
			{
				System.out.println("Stock expand icon is displayed");
			}
			else
			{
				System.out.println("Stock expand icon not displayed");
			}
			boolean expand_text=driver.findElement(By.id("com.mbb.mketrade:id/txt_expand_retated_stocks")).isDisplayed();
			if(expand_text)
			{
				System.out.println("Expand text is available");
			}
			else
			{
				System.out.println("Expand text is not available");
			}
			
			
		}
		else
		{
			System.out.println("No Related stocks label available");
		}
		boolean buysellbutton=driver.findElement(By.id("com.mbb.mketrade:id/btn_settings")).isDisplayed();
		if(buysellbutton)
		{
			driver.findElement(By.id("com.mbb.mketrade:id/btn_settings")).click();
		}
		else
		{
			System.out.println("Buy sell button is not displayed");
		}
		//click sell or buy and close
		driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).click();
		driver.findElement(By.id("com.mbb.mketrade:id/img_close")).click();
		
	}

}
