package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import junit.framework.Assert;

public class Menus 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^user login to the application$")
	public void loginwithvalid_credentials() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		
	}
	@When("^The user click the icon in the right corner top of the page$")
	public void clickrightcorner_menu()
	{
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/title_bar_right_menu")));
		boolean findmenu=driver.findElement(By.id("com.mbb.mketrade:id/title_bar_right_menu")).isDisplayed();
		if(findmenu)
		{
			driver.findElement(By.id("com.mbb.mketrade:id/title_bar_right_menu")).click();
			System.out.println("Find menu available");
		}
		else
		{
			System.out.println("Find Menu not available");
		}	
		
	}
	@Then("^The Menus of the entire should be displayed$")
	public void verify_menu()
	{
		String Home_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Home']")).getText();
		String Expected_homeLabel="Home";
		if(Home_label.equalsIgnoreCase(Expected_homeLabel))
		{
			System.out.println("Menu Pass");
		}
		else
		{
			System.out.println("Home not available");
		}
		String Discover_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).getText();
		String Expected_discoverLabel="Discover";
		if(Discover_label.equalsIgnoreCase(Expected_discoverLabel))
		{
			System.out.println("Discover menu Pass");
		}
		else
		{
			System.out.println("Discover not available");
		}
		String Alerts_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Alerts']")).getText();
		String Expected_Alerts="Alerts";
		if(Alerts_label.equalsIgnoreCase(Expected_Alerts))
		{
			System.out.println("Alerts menu Pass");
			String second_title=driver.findElement(By.id("com.mbb.mketrade:id/tv_second_title")).getText();
			System.out.println(second_title);
		}
		else
		{
			System.out.println("Alert menu not available");
		}
		
		String Watchlist_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Watchlist']")).getText();
		String Expected_Watchlist="Watchlist";
		if(Watchlist_label.equalsIgnoreCase(Expected_Watchlist))
		{
			System.out.println("Watchlist menu Pass");
		}
		else
		{
			System.out.println("Watchlist menu not available");
		}
		String Top_Movers_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Top Movers']")).getText();
		String Expected_Top_Movers="Top Movers";
		if(Top_Movers_label.equalsIgnoreCase(Expected_Top_Movers))
		{
			System.out.println("Top Movers menu Pass");
		}
		else
		{
			System.out.println("Top Movers menu not available");
		}
		String Orders_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Orders']")).getText();
		String Expected_Orders="Orders";
		if(Orders_label.equalsIgnoreCase(Expected_Orders))
		{
			System.out.println("Orders menu Pass");
			String secondorders_title=driver.findElement(By.id("com.mbb.mketrade:id/tv_second_title")).getText();
			System.out.println("secondorders_title" + secondorders_title);
		}
		else
		{
			System.out.println("Orders menu not available");
		}
		String Stock_Portfolio_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Stock Portfolio']")).getText();
		String Expected_Stock_Portfolio="Stock Portfolio";
		if(Stock_Portfolio_label.equalsIgnoreCase(Expected_Stock_Portfolio))
		{
			System.out.println("Stock Portfolio menu Pass");
		}
		else
		{
			System.out.println("Stock Portfolio menu not available");
		}
		String Account_Summary_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Account Summary']")).getText();
		String Expected_Account_Summary="Account Summary";
		if(Account_Summary_label.equalsIgnoreCase(Expected_Account_Summary))
		{
			System.out.println("Account Summary menu Pass");
		}
		else
		{
			System.out.println("Account Summary menu not available");
		}
		String Stock_Screener_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Stock Screener']")).getText();
		String Expected_Stock_Screener="Stock Screener";
		if(Stock_Screener_label.equalsIgnoreCase(Expected_Stock_Screener))
		{
			System.out.println("Stock_Screener menu Pass");
		}
		else
		{
			System.out.println("Stock_Screener menu not available");
		}
		//String Help_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Help']")).getText();
		String Help_label=driver.findElement(By.id("com.mbb.mketrade:id/btn_help")).getText();
		String Expected_Help="Help";
		if(Help_label.equalsIgnoreCase(Expected_Help))
		{
			System.out.println("Help menu Pass");
		}
		else
		{
			System.out.println("Help menu not available");
		}
		//String Settings_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Settings']")).getText();
		String Settings_label=driver.findElement(By.id("com.mbb.mketrade:id/btn_settings")).getText();
		String Expected_Settings="Settings";
		if(Settings_label.equalsIgnoreCase(Expected_Settings))
		{
			System.out.println("Settings menu Pass");
		}
		else
		{
			System.out.println("Settings menu not available");
		}
		
		//String Logout_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Logout']")).getText();
		String Logout_label=driver.findElement(By.id("com.mbb.mketrade:id/btn_logout")).getText();
		String Expected_Logout="Logout";
		if(Logout_label.equalsIgnoreCase(Expected_Logout))
		{
			System.out.println("Logout menu Pass");
		}
		else
		{
			System.out.println("Logout menu not available");
		}
		boolean logo=driver.findElement(By.id("com.mbb.mketrade:id/img_log")).isDisplayed();
		if(logo)
		{
			System.out.println("Logo displayed");
		}
		else
		{
			System.out.println("Logo not displayed");
		}
		
	}

}
