package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ch.qos.logback.core.net.SyslogOutputStream;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class DiscoverMarketIndices 
{
	AndroidDriver<AndroidElement> driver;
	@Given("^User Navigated to the Discover page Market$")
	public void navigation_discover_Market() throws MalformedURLException
	{
		File appDir = new File("src");
	     File app = new File(appDir, "app-debug.apk");
	     DesiredCapabilities capabilities = new DesiredCapabilities();
	     capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	     capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	     driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	     
	     driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	     
	     driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		 driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		 driver.pressKeyCode(66); 
		 driver.getKeyboard();
		 driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		 
	}
	
	@When("^User scrolls to the Market Indices section$")
	public void scroll_MarketIndices()
	{
		System.out.println("Navigate to Market Indices");
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.40);
		int bottom_y=(int) (height*0.10);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();

		
	}
	
	@Then("^The details of the Market Indices are displayed$")
	public void displayMarketIndices()
	{
		System.out.println("Market Indices Displayed");
		String getIndex=driver.findElement(By.xpath("//android.widget.TextView[@index='0']")).getText();
		System.out.println("getIndex"+ getIndex);
		
		String stock_name=driver.findElement(By.id("com.mbb.mketrade:id/stock_name")).getText();
		System.out.println("stock_name"+ stock_name);
		
		String text_code=driver.findElement(By.id("com.mbb.mketrade:id/txt_code")).getText();
		System.out.println(text_code);
		
		String last_price=driver.findElement(By.xpath("//android.widget.TextView[@index='1']")).getText();
		System.out.println(last_price);
		
		String stockPrice=driver.findElement(By.id("com.mbb.mketrade:id/stock_price")).getText();
		System.out.println(stockPrice);
		
		boolean gainorloss=driver.findElement(By.id("com.mbb.mketrade:id/gain_or_loss")).isDisplayed();
		if(gainorloss)
		{
			System.out.println("Gain loss button Displayed");
		}
		else
		{
			System.out.println("Gain loss button not displayed");
		}
		String lastprice=driver.findElement(By.id("com.mbb.mketrade:id/last_price")).getText();
		System.out.println(lastprice);
		
		String lastpercentage=driver.findElement(By.id("com.mbb.mketrade:id/last_price_percentage")).getText();
		System.out.println(lastpercentage);
	}
	
	@When("^User clicks the Watchlist name in the Market Indices section$")
	public void click_Watchlist()
	{
		//driver.findElement(By.id("com.mbb.mketrade:id/stock_name")).click();
		driver.findElement(By.xpath("//android.widget.TextView[@text='Bursa Malaysia']")).click();
	}
	
	@Then("^Page navigtes to the corresponding watchlist details page$")
	public void watchlistdetails_page()
	{
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/section_title")));
		String gettitle=driver.findElement(By.id("com.mbb.mketrade:id/section_title")).getText();
		System.out.println("gettitle"+ gettitle);
		boolean Marketavailable=driver.findElement(By.xpath("//android.widget.TextView[@text='Market']")).isDisplayed();
		if(Marketavailable)
		{
			String marketname=driver.findElement(By.xpath("//android.widget.TextView[@text='Market']")).getText();
			System.out.println("marketname"+ marketname);
		}
		boolean indexavailable=driver.findElement(By.xpath("//android.widget.TextView[@text='Index Details']")).isDisplayed();
		if(indexavailable)
		{
			String getindexdetails=driver.findElement(By.xpath("//android.widget.TextView[@text='Index Details']")).getText();
			System.out.println(getindexdetails);
		}
					
	}
	@And("^Market Details will be displayed$")
	public void MarketDetails_View()
	{
		boolean Market=driver.findElement(By.xpath("//android.widget.TextView[@text='Market']")).isDisplayed();
		if(Market)
		{
			String Marketname=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name")).getText();
			System.out.println("Marketname"+ Marketname);
			
			String lastupdated_text=driver.findElement(By.id("com.mbb.mketrade:id/txt_last_update")).getText();
			System.out.println("lastupdated_text"+ lastupdated_text);
			
			String lastupdatedvalue=driver.findElement(By.id("com.mbb.mketrade:id/txt_last_value")).getText();
			System.out.println("lastupdatedvalue"+ lastupdatedvalue);
			
			String net_worth=driver.findElement(By.id("com.mbb.mketrade:id/txt_net_worth")).getText();
			System.out.println("net_worth"+ net_worth);
			
			String gainorloss=driver.findElement(By.id("com.mbb.mketrade:id/gain_or_loss")).getText();
			System.out.println(gainorloss);
			
			String last_price_percentage=driver.findElement(By.id("com.mbb.mketrade:id/last_price_percentage")).getText();
			System.out.println(last_price_percentage);
			
			String target_price_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_consensus_target_price_label")).getText();
			System.out.println(target_price_label);
			
			String target_price=driver.findElement(By.id("com.mbb.mketrade:id/txt_consensus_target_price")).getText();
			System.out.println(target_price);
			
			String Status_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_status_label_label")).getText();
			System.out.println(Status_label);
			
			String Status_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_status")).getText();
			System.out.println(Status_value);
			
			String Turnover_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_turnover_label")).getText();
			System.out.println(Turnover_label);
			
			String Turnover_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_turnover")).getText();
			System.out.println(Turnover_value);
			
			String value_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_value_label")).getText();
			System.out.println(value_label);
			
			String values=driver.findElement(By.id("com.mbb.mketrade:id/txt_value")).getText();
			System.out.println(values);
			
			String name_chart=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name_chart")).getText();
			System.out.println(name_chart);
			//Up
			String up_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Up']")).getText();
			System.out.println(up_label);
			
			String up_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_up_value")).getText();
			System.out.println(up_value);
			
			String up_percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_up_percentage")).getText();
			System.out.println(up_percentage);
			//Down
			String down_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Down']")).getText();
			System.out.println(down_label);
			
			String down_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_down_value")).getText();
			System.out.println(down_value);
			
			String down_percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_down_percentage")).getText();
			System.out.println(down_percentage);
			//Unchange
			String Unchange_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Unchange']")).getText();
			System.out.println(Unchange_label);
			
			String unchange_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_unchange_value")).getText();
			System.out.println(unchange_value);
			
			String unchange_percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_unchange_percentage")).getText();
			System.out.println(unchange_percentage);
			
			//UnTrade
			String UnTrade_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Untrade']")).getText();
			System.out.println(UnTrade_label);
			
			String UnTrade_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_untrade_value")).getText();
			System.out.println(UnTrade_value);
			
			String unTrade_percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_untrade_percentage")).getText();
			System.out.println(unTrade_percentage);
			
			//Spend
			String Spend_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Spnd']")).getText();
			System.out.println(Spend_label);
			
			String Spend_value=driver.findElement(By.id("com.mbb.mketrade:id/txt_spnd_value")).getText();
			System.out.println(Spend_value);
			
			String Spend_percentage=driver.findElement(By.id("com.mbb.mketrade:id/txt_spnd_percentage")).getText();
			System.out.println(Spend_percentage);
								
		}
		else
		{
			System.out.println("Market Details page not available");
		}		
	}
	
	
	/*@Given("^User navigated to the MarketDetails page$")
	public void MarketDetailspage_navigated()
	{
		System.out.println("Navigated market page");
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Market']")));
		boolean Marketpage=driver.findElement(By.xpath("//android.widget.TextView[@text='Market']")).isDisplayed();
		if(Marketpage)
		{
			System.out.println("market details avaialble");
		}
		else
		{
			System.out.println("Market details page not available");
		}
			
	}*/
	@When("^Swipe the Whole Market chart$")
	public void Swipe_Marketchart()
	{
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/txt_market_name_chart")));
		
		Dimension size = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx = (int) (size.width * 0.90);
		  int endx = (int) (size.width * 0.05);
		  int starty = size.height / 2;
		  
		  TouchAction ta=new TouchAction(driver)
		  .press(PointOption.point(startx,starty)).moveTo(PointOption.point(endx,starty)).release().perform();
		  String next_slider=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name_chart")).getText();
		  System.out.println(next_slider);
	}
	
	@Then("^The slider should move to the next corresponding page$")
	public void verify_correspondingpage_details()
	{
		System.out.println("Last Moving slider");
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.mbb.mketrade:id/txt_market_name_chart")));
		
		Dimension size = driver.manage().window().getSize();
		  System.out.println(size);
		  int startx = (int) (size.width * 0.90);
		  int endx = (int) (size.width * 0.05);
		  int starty = size.height / 2;
		  
		  TouchAction ta=new TouchAction(driver)
		  .press(PointOption.point(startx,starty)).moveTo(PointOption.point(endx,starty)).release().perform();
		  String last_slider=driver.findElement(By.id("com.mbb.mketrade:id/txt_market_name_chart")).getText();
		  System.out.println(last_slider);
	}
	@And("^Index Details will be displayed$")
	public void IndexDetails()
	{
		System.out.println("Index Details displayed");
		
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Index Details']")));
		driver.findElement(By.xpath("//android.widget.TextView[@text='Index Details']")).click();
		boolean indexdetails=driver.findElement(By.xpath("//android.widget.TextView[@text='Index Details']")).isDisplayed();
		if(indexdetails)
		{
			String vector_details=driver.findElement(By.xpath("//android.widget.TextView[@text='Sector']")).getText();
			System.out.println("vector_details" + vector_details);
			String vector_values=driver.findElement(By.id("com.mbb.mketrade:id/sector_name")).getText();
			System.out.println("vector_values" + vector_values);
			
			String Mkt_valuelabel=driver.findElement(By.xpath("//android.widget.TextView[@text='Mkt Value']")).getText();
			System.out.println("Mkt_value"+ Mkt_valuelabel);
			
			String Mktvalues=driver.findElement(By.id("com.mbb.mketrade:id/market_value")).getText();
			System.out.println("Mktvalues" + Mktvalues);
			
			String Performancelabel=driver.findElement(By.xpath("//android.widget.TextView[@text='Performance']")).getText();
			System.out.println(Performancelabel);
			
			String gainorloss=driver.findElement(By.id("com.mbb.mketrade:id/gain_or_loss")).getText();
			System.out.println("gainorloss" + gainorloss);
			
			String performance_percentage=driver.findElement(By.id("com.mbb.mketrade:id/performance_percentage")).getText();
			System.out.println("performance_percentage" + performance_percentage);
			
			String lasupdated_label=driver.findElement(By.id("com.mbb.mketrade:id/txt_last_update")).getText();
			System.out.println(lasupdated_label);
			
			String lastupdated_values=driver.findElement(By.id("com.mbb.mketrade:id/txt_last_value")).getText();
			System.out.println(lastupdated_values);
			
			
			Dimension size=driver.manage().window().getSize();
			int height=size.getHeight();
			int width=size.getWidth();
			int x=width/2;
			int top_y=(int)(height* 0.80);
			int bottom_y=(int) (height*0.20);	
			
			TouchAction ta = new TouchAction(driver);
	        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
		}
		else
		{
			System.out.println("Index Details not available");
		}
				
		
		
		
	}
}
