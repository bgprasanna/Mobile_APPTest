package stepDefinitions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class DiscoverViewAll 
{
	AndroidDriver<AndroidElement> driver;
	@Given("User Navigated to the MKE Insights View All in the Discover section")
	public void navigate_to_viewAllsection() throws MalformedURLException
	{
		File appDir = new File("src");
	    File app = new File(appDir, "app-debug.apk");
	    DesiredCapabilities capabilities = new DesiredCapabilities();
	    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Gokul_Emulator");
	    capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	    driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities );
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//android.widget.Button[@text='LOGIN']")).click();
	    
	    driver.findElement(By.id("com.mbb.mketrade:id/et_username")).sendKeys("mt001");
		driver.findElement(By.id("com.mbb.mketrade:id/et_password")).sendKeys("abcd1234");
		driver.pressKeyCode(66); 
		driver.getKeyboard();
		
		driver.findElement(By.id("com.mbb.mketrade:id/btn_login")).click();
		
		driver.findElement(By.xpath("//android.widget.TextView[@text='Discover']")).click();
		
	}
	
	@When("^User clicks the View All option$")
	public void ViewAlloption()
	{
		driver.findElement(By.xpath("//android.widget.TextView[@text='View All']")).click();	
	}
	@Then("^The menu options TopView Videos MicoViews TopIdeas are available$")
	public void viewall_options()
	{
		// Top View
		WebDriverWait wait=new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Top View']")));
		String Topview_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Top View']")).getText();
		System.out.println("Topview_label"+Topview_label);
		String Topview_expected="Top View";
		Assert.assertEquals(Topview_label, Topview_expected);
		
		// Videos
		
		String video_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Videos']")).getText();
		System.out.println("video_label" + video_label);
		String Videos_expected="Videos";
		Assert.assertEquals(video_label, Videos_expected);
		//Macro Views
		
		String marco_label=driver.findElement(By.xpath("//android.widget.TextView[@text='Marco Views']")).getText();
		System.out.println("macro_label" + marco_label);
		String Views_expected="Marco Views";
		Assert.assertEquals(marco_label, Views_expected);
		
		// Top Ideas
		
		String Top_Ideas=driver.findElement(By.xpath("//android.widget.TextView[@text='Top Ideas']")).getText();
		System.out.println("Top_Ideas" + Top_Ideas);
		String TopIdeas_expected="Top Ideas";
		Assert.assertEquals(Top_Ideas, TopIdeas_expected);
				
	}
	
	@Given("^User Navigated to the MKE insights menu options page$")
	public void navigate_toMMEInsights()
	{
		boolean verify_Topview=driver.findElement(By.xpath("//android.widget.TextView[@text='Top View']")).isDisplayed();
		if(verify_Topview)
		{
			System.out.println("Top view is displayed");
		}
		else
		{
			System.out.println("Top view is not displayed");
		}
	}
	@When("^User clicks the TopView menu$")
	public void click_topview_menu()
	{
		driver.findElement(By.xpath("//android.widget.TextView[@text='Top View']")).click();
	}
	
	@Then("^Entire Details of TopView should be displayed$")
	public void view_Topview_page()
	{
		
		//Buy or Sell
		String buyorsell=driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).getText();
		if(buyorsell.equalsIgnoreCase("buy"))
		{
			System.out.println("Buy value"+ buyorsell);
		}
		else if(buyorsell.equalsIgnoreCase("sell"))
		{
			System.out.println("Sell value"+ buyorsell);
		}
		else
		{
			System.out.println("Invalid value");
		}
		// Stock Price
		String stock_price=driver.findElement(By.id("com.mbb.mketrade:id/stock_price")).getText();
		System.out.println("stock_price"+ stock_price);
		
		// Insights time
		String insights_time=driver.findElement(By.id("com.mbb.mketrade:id/mke_insights_time")).getText();
		System.out.println(insights_time);
		
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();

	}
	
	@When("^User clicks the Videos menu$")
	public void userclicks_videos()
	{
		WebDriverWait wait=new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Videos']")));		
		System.out.println("Videos menu is available");
		driver.findElement(By.xpath("//android.widget.TextView[@text='Videos']")).click();
		
	}
	@Then("^Entire Details of Videos should be displayed$")
	public void view_videodetails()
	{
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();
	}
	@When("^User clicks the Marco Views menu$")
	public void user_click_Marcoview()
	{
		System.out.println("Marco Views are available");
		driver.findElement(By.xpath("//android.widget.TextView[@text='Marco Views']")).click();
	}
	
	@Then("^Entire Details of Marco Views should be displayed$")		
	public void Marcoview_details()
	{
		//Buy or Sell
		String buyorsell=driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).getText();
		if(buyorsell.equalsIgnoreCase("buy"))
		{
			System.out.println("Buy value"+ buyorsell);
		}
		else if(buyorsell.equalsIgnoreCase("sell"))
		{
			System.out.println("Sell value"+ buyorsell);
		}
		else
		{
			System.out.println("Invalid value");
		}
		// Stock Price
		String stock_price=driver.findElement(By.id("com.mbb.mketrade:id/stock_price")).getText();
		System.out.println("stock_price"+ stock_price);
		
		// Insights time
		String insights_time=driver.findElement(By.id("com.mbb.mketrade:id/mke_insights_time")).getText();
		System.out.println(insights_time);
		
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();

	}
	@When("^User clicks the Top ideas menu$")
	public void clickTopIdeas()
	{
		System.out.println("Top Ideas");
		driver.findElement(By.xpath("//android.widget.TextView[@text='Top Ideas']")).click();
	}
	@Then("^Entire Details of Top Ideas should be displayed$")
	public void view_TopIdeas_details()
	{
		//Buy or Sell
		String buyorsell=driver.findElement(By.id("com.mbb.mketrade:id/buyOrSell")).getText();
		if(buyorsell.equalsIgnoreCase("buy"))
		{
			System.out.println("Buy value"+ buyorsell);
		}
		else if(buyorsell.equalsIgnoreCase("sell"))
		{
			System.out.println("Sell value"+ buyorsell);
		}
		else
		{
			System.out.println("Invalid value");
		}
		// Stock Price
		String stock_price=driver.findElement(By.id("com.mbb.mketrade:id/stock_price")).getText();
		System.out.println("stock_price"+ stock_price);
		
		// Insights time
		String insights_time=driver.findElement(By.id("com.mbb.mketrade:id/mke_insights_time")).getText();
		System.out.println(insights_time);
		
		
		Dimension size=driver.manage().window().getSize();
		int height=size.getHeight();
		int width=size.getWidth();
		int x=width/2;
		int top_y=(int)(height* 0.80);
		int bottom_y=(int) (height*0.20);	
		
		TouchAction ta = new TouchAction(driver);
        ta.press(PointOption.point(x, top_y)).moveTo(PointOption.point(x, bottom_y)).release().perform();

	}
	
}
