package runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/functionalTest", glue={"stepDefinitions"}, tags={"@End2Test"}, plugin = { "pretty", "html:target" }, monochrome = true)
public class TestRunner {
	

}
