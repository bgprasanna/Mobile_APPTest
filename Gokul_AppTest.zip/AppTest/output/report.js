$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Home.feature");
formatter.feature({
  "line": 2,
  "name": "Verifying Trade balance",
  "description": "",
  "id": "verifying-trade-balance",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Login"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Validating the Today\u0027s Remaining Trade Balance",
  "description": "Given: Navigated to the Home page\r\nWhen: The user clicks the dropdown button in the page\r\nThen: Remaining Trade Balance, Total Outstanding payment, Total Trade Balance, Margin Balance details will be displayed",
  "id": "verifying-trade-balance;validating-the-today\u0027s-remaining-trade-balance",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.uri("Login.feature");
formatter.feature({
  "line": 2,
  "name": "Login user validation",
  "description": "",
  "id": "login-user-validation",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Login"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Validate the Existing user access the application with valid credential",
  "description": "",
  "id": "login-user-validation;validate-the-existing-user-access-the-application-with-valid-credential",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "Open the application on mobile device",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "click the Login button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter the username as  password as on the Login page",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "click the Login Button",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User should Navigate to the Home screen",
  "keyword": "Then "
});
formatter.match({
  "location": "Loginpage.Launchapplication()"
});
formatter.result({
  "duration": 27002421335,
  "status": "passed"
});
formatter.match({
  "location": "Loginpage.click_login()"
});
formatter.result({
  "duration": 29810070878,
  "status": "passed"
});
formatter.match({
  "location": "Loginpage.enter_the_username_as_password_as_on_the_Login_page()"
});
formatter.result({
  "duration": 13181804955,
  "status": "passed"
});
formatter.match({
  "location": "Loginpage.click_loginbutton()"
});
formatter.result({
  "duration": 1513024438,
  "status": "passed"
});
formatter.match({
  "location": "Loginpage.verifying_navigating_homepage()"
});
formatter.result({
  "duration": 7995751250,
  "status": "passed"
});
});